# Romin Khan — Academic Portfolio

## Preview locally
1. Extract this ZIP.
2. Keep `index.html` and the entire `assets` folder together.
3. Open `index.html` in Chrome.

The page includes local fallbacks for project and environmental visuals, so cards remain illustrated even if remote Unsplash images are blocked. If internet access is available, the selected Unsplash photographs load first. The portrait and assignment PDFs are packaged locally.

## Included assignment PDFs
- `assets/carbon-footprint.pdf`
- `assets/device-anatomy.pdf`
- `assets/ewaste-crossword.pdf`
- `assets/sustainability-pledge.pdf`

This is a static site. Project cards describe the supplied project ideas; no repository links are included.
